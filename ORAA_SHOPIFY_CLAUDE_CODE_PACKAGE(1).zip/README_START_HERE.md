# ORAA SHOPIFY --- CLAUDE CODE PACKAGE

**Projet concerné : ORAA Shopify exclusivement.**\
Ne pas confondre avec un ancien ou autre projet ORAA/WordPress.

## But du package

Ce dossier transmet à Claude Code la direction d'expérience, de marque,
de commerce et de qualité définie pour la boutique ORAA Shopify.

Il ne constitue pas une autorisation de modifier ou déployer la boutique
en production.

## Ordre de lecture

Avant ces fichiers, Claude Code doit lire dans le repository réel : 1.
`00_FOUNDATION/AGENT_PROTOCOL.md` 2. les autres fichiers de
`00_FOUNDATION` 3. gouvernance et architecture applicables 4.
`17_DECISIONS` / ADR 5. taxonomie 6.
`20_AI_PACKAGE/HANDOVER_CLAUDE_CODE.md`

Puis lire ce dossier dans cet ordre : 1.
`ORAA_SHOPIFY_MASTER_INDEX_CROSS_AUDIT.md` 2.
`ORAA_SHOPIFY_BRAND_SYSTEM.md` 3.
`ORAA_SHOPIFY_MONDE_ORAA_MASTER_EXPERIENCE_SPEC.md` 4.
`ORAA_SHOPIFY_HOUSES_SYSTEM.md` 5.
`ORAA_SHOPIFY_EXPERIENCE_SYSTEM_MAISON_PILOTE_TECH.md` 6.
`ORAA_SHOPIFY_COMMERCE_TRANSACTION_SYSTEM.md` 7.
`ORAA_SHOPIFY_QUALITY_MOBILE_PERFORMANCE_ACCESSIBILITY_SECURITY.md`

## Première mission de Claude Code

Faire une lecture et une réconciliation documentaire AVANT tout code
lourd : - vérifier le statut réel des ADR ; - vérifier la taxonomie
actuelle ; - vérifier Mode / Voyage & Aventure ; - vérifier ADR-0005 et
ADR-0006 ; - vérifier la phase réelle du chantier Shopify ; - identifier
toute contradiction entre repository et nouvelles spécifications ; -
produire un rapport d'écarts ; - ne rien résoudre silencieusement ; - ne
pas déployer.

## Règle centrale

Le repository réel et ses lois fondamentales restent supérieurs à ce
package.

> Comprendre → confronter → signaler → proposer → faire valider →
> construire par lots testables.
